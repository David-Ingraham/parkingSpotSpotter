# My First Project > 2025-04-11 10:08am
https://universe.roboflow.com/work-qh31v/my-first-project-kutpe

Provided by a Roboflow user
License: CC BY 4.0

